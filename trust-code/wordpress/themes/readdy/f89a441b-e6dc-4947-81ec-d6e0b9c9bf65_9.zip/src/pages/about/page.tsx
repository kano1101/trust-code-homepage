
import Header from '../home/components/Header';
import Footer from '../home/components/Footer';

export default function About() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-white flex flex-col">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 py-12 flex-grow">
        <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
          <div className="text-center mb-12">
            <div className="w-20 h-20 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ri-code-s-slash-line text-purple-900 text-3xl"></i>
            </div>
            <h1 className="text-4xl font-bold text-purple-800 mb-4" style={{fontFamily: '"Pacifico", serif'}}>
              About TrustCode
            </h1>
            <p className="text-xl text-gray-600">ともに信頼あるコードを築こう</p>
          </div>

          <div className="prose prose-lg max-w-none">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
              <div>
                <img 
                  src="https://readdy.ai/api/search-image?query=Professional%20software%20engineer%20working%20at%20a%20bakery%2C%20modern%20office%20environment%20with%20baking%20equipment%20in%20background%2C%20warm%20lighting%2C%20professional%20portrait%20style%2C%20clean%20and%20minimalist%20aesthetic&width=400&height=300&seq=about-aqun&orientation=landscape"
                  alt="Aqun - ケーキ屋の社内エンジニア"
                  className="w-full h-64 object-cover rounded-xl shadow-md"
                />
              </div>
              <div className="flex flex-col justify-center">
                <h2 className="text-2xl font-bold text-purple-800 mb-4">Aqunについて</h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  1989年11月1日生まれ。プログラマ、花屋、医療従事者として職を移り変わり、現在はケーキ屋の社内エンジニアとして働いています。
                </p>
                <p className="text-gray-700 leading-relaxed">
                  職場や業界の経済効果を最大化する方法を模索しながら、日々の業務とライフタイムを通じて世間に最大限自分の生きた証を残すことを目指しています。
                </p>
              </div>
            </div>

            <div className="bg-gradient-to-r from-purple-100 to-yellow-100 rounded-xl p-8 mb-12">
              <h2 className="text-2xl font-bold text-purple-800 mb-6">サイトのミッション</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white rounded-lg p-6 shadow-sm">
                  <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center mb-4">
                    <i className="ri-lightbulb-line text-white text-xl"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-purple-800 mb-2">自己啓発の発信</h3>
                  <p className="text-gray-600">日々の学びと経験を通じて得た自己啓発・美学を発信し、読者の成長をサポートします。</p>
                </div>
                <div className="bg-white rounded-lg p-6 shadow-sm">
                  <div className="w-12 h-12 bg-yellow-500 rounded-lg flex items-center justify-center mb-4">
                    <i className="ri-code-line text-white text-xl"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-purple-800 mb-2">技術の共有</h3>
                  <p className="text-gray-600">プログラミングやAI・IT技術について、実践的な知識と経験を共有します。</p>
                </div>
              </div>
            </div>

            <div className="mb-12">
              <h2 className="text-2xl font-bold text-purple-800 mb-6">コンテンツカテゴリ</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white border border-purple-200 rounded-lg p-4 text-center hover:shadow-md transition-shadow cursor-pointer">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <i className="ri-brain-line text-white text-xl"></i>
                  </div>
                  <h3 className="font-semibold text-purple-800">自己啓発</h3>
                  <p className="text-sm text-gray-600 mt-1">成長マインドセット</p>
                </div>
                <div className="bg-white border border-purple-200 rounded-lg p-4 text-center hover:shadow-md transition-shadow cursor-pointer">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <i className="ri-fish-line text-white text-xl"></i>
                  </div>
                  <h3 className="font-semibold text-purple-800">アクアリウム</h3>
                  <p className="text-sm text-gray-600 mt-1">水槽管理と魚の世界</p>
                </div>
                <div className="bg-white border border-purple-200 rounded-lg p-4 text-center hover:shadow-md transition-shadow cursor-pointer">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <i className="ri-smartphone-line text-white text-xl"></i>
                  </div>
                  <h3 className="font-semibold text-purple-800">ガジェット</h3>
                  <p className="text-sm text-gray-600 mt-1">最新テクノロジー</p>
                </div>
                <div className="bg-white border border-purple-200 rounded-lg p-4 text-center hover:shadow-md transition-shadow cursor-pointer">
                  <div className="w-12 h-12 bg-gradient-to-br from-yellow-500 to-yellow-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <i className="ri-code-s-slash-line text-white text-xl"></i>
                  </div>
                  <h3 className="font-semibold text-purple-800">プログラミング</h3>
                  <p className="text-sm text-gray-600 mt-1">開発技術とAI</p>
                </div>
              </div>
            </div>

            <div className="bg-purple-50 rounded-xl p-8 text-center">
              <h2 className="text-2xl font-bold text-purple-800 mb-4">一緒に成長しましょう</h2>
              <p className="text-gray-700 leading-relaxed mb-6">
                このサイトを通じて、私の経験と学びを共有し、読者の皆様と一緒に成長していきたいと思います。
                質問やご意見がございましたら、お気軽にお問い合わせください。
              </p>
              <a 
                href="/contact" 
                className="inline-flex items-center px-6 py-3 bg-purple-600 text-white font-semibold rounded-lg hover:bg-purple-7… transition-colors cursor-pointer whitespace-nowrap"
              >
                <i className="ri-mail-line mr-2"></i>
                お問い合わせ
              </a>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
