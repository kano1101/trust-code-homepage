
import { useState } from 'react';
import { useWordPressConfig } from '../../../hooks/useWordPressConfig';
import { blogPosts } from '../../../data/posts';
import Header from '../../home/components/Header';
import Footer from '../../home/components/Footer';

export default function SelfDevelopment() {
  const { config, loading } = useWordPressConfig();
  const [sortBy, setSortBy] = useState<'date' | 'title'>('date');

  // 自己啓発カテゴリの記事をフィルタリング
  const selfDevelopmentPosts = blogPosts.filter(post => 
    post.category === '自己啓発' || 
    post.tags.some(tag => tag.includes('自己啓発'))
  );

  // ソート機能
  const sortedPosts = [...selfDevelopmentPosts].sort((a, b) => {
    if (sortBy === 'date') {
      return new Date(b.date).getTime() - new Date(a.date).getTime();
    } else {
      return a.title.localeCompare(b.title);
    }
  });

  if (loading || !config) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-white flex flex-col">
        <Header />
        <main className="max-w-7xl mx-auto px-4 py-12 flex-grow">
          <div className="animate-pulse">
            <div className="h-12 bg-purple-100 rounded w-1/3 mb-8"></div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <div className="space-y-6">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="bg-white rounded-2xl shadow-lg p-6">
                      <div className="h-6 bg-purple-100 rounded w-3/4 mb-4"></div>
                      <div className="h-4 bg-purple-50 rounded mb-2"></div>
                      <div className="h-4 bg-purple-50 rounded w-2/3"></div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="space-y-6">
                <div className="bg-white rounded-2xl shadow-lg p-6">
                  <div className="h-6 bg-purple-100 rounded w-1/2 mb-4"></div>
                  <div className="space-y-2">
                    {[...Array(5)].map((_, i) => (
                      <div key={i} className="h-4 bg-purple-50 rounded"></div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-white flex flex-col">
      <Header />
      
      {/* ヒーローセクション */}
      <section className="relative py-20 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=Inspiring%20self-development%20concept%20with%20growing%20plant%2C%20books%2C%20lightbulb%2C%20and%20upward%20arrow%20symbols%2C%20warm%20golden%20and%20purple%20gradient%20background%2C%20motivational%20and%20personal%20growth%20theme%2C%20clean%20modern%20design%2C%20professional%20aesthetic&width=1200&height=400&seq=self-dev-hero&orientation=landscape')`
          }}
        >
          <div className={`absolute inset-0 bg-gradient-to-r ${config.theme.gradients.hero}`}></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4">
          <div className="flex items-center mb-6">
            <div className={`w-16 h-16 bg-gradient-to-br ${config.theme.gradients.card} rounded-full flex items-center justify-center mr-4`}>
              <i className="ri-lightbulb-line text-2xl text-white"></i>
            </div>
            <div>
              <h1 className="text-5xl font-bold text-white mb-2">
                自己啓発
              </h1>
              <p className="text-xl text-purple-100">
                {selfDevelopmentPosts.length}件の記事
              </p>
            </div>
          </div>
          <p className="text-lg text-purple-100 max-w-3xl">
            人生をより豊かにするための学びと成長の記録。日々の気づきから実践的なノウハウまで、
            自己効力感を高めるためのヒントをお届けします。
          </p>
        </div>
      </section>

      <main className="max-w-7xl mx-auto px-4 py-12 flex-grow">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* メインコンテンツ */}
          <div className="lg:col-span-2">
            {/* ソート機能 */}
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold text-purple-800">
                記事一覧
              </h2>
              <div className="flex items-center space-x-4">
                <span className="text-sm text-gray-600">並び順:</span>
                <div className="flex bg-white rounded-full border border-purple-200 p-1">
                  <button
                    onClick={() => setSortBy('date')}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-all cursor-pointer whitespace-nowrap ${
                      sortBy === 'date'
                        ? `bg-gradient-to-r ${config.theme.gradients.button} text-white`
                        : 'text-purple-700 hover:bg-purple-50'
                    }`}
                  >
                    新着順
                  </button>
                  <button
                    onClick={() => setSortBy('title')}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-all cursor-pointer whitespace-nowrap ${
                      sortBy === 'title'
                        ? `bg-gradient-to-r ${config.theme.gradients.button} text-white`
                        : 'text-purple-700 hover:bg-purple-50'
                    }`}
                  >
                    タイトル順
                  </button>
                </div>
              </div>
            </div>

            {/* 記事一覧 */}
            {sortedPosts.length > 0 ? (
              <div className="space-y-8">
                {sortedPosts.map((post) => (
                  <article
                    key={post.id}
                    className="bg-white rounded-2xl shadow-lg border border-purple-100 overflow-hidden hover:shadow-xl transition-all cursor-pointer group"
                  >
                    <div className="md:flex">
                      <div 
                        className="md:w-1/3 h-64 md:h-auto bg-cover bg-center relative"
                        style={{
                          backgroundImage: `url('https://readdy.ai/api/search-image?query=Self-development%20and%20personal%20growth%20illustration%2C%20inspiring%20books%2C%20lightbulb%2C%20growth%20chart%2C%20motivational%20symbols%2C%20warm%20golden%20and%20purple%20colors%2C%20clean%20modern%20design%2C%20professional%20aesthetic&width=400&height=300&seq=post-${post.id}-thumb&orientation=landscape')`
                        }}
                      >
                        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                        <div className="absolute top-4 left-4">
                          <span className={`bg-gradient-to-r ${config.theme.gradients.button} text-white px-3 py-1 rounded-full text-sm font-medium`}>
                            {post.category}
                          </span>
                        </div>
                      </div>
                      
                      <div className="md:w-2/3 p-8">
                        <div className="flex items-center text-sm text-gray-500 mb-3">
                          <span className="flex items-center mr-4">
                            <i className="ri-calendar-line mr-1"></i>
                            {post.date}
                          </span>
                          <span className="flex items-center mr-4">
                            <i className="ri-user-line mr-1"></i>
                            {post.author}
                          </span>
                          <span className="flex items-center">
                            <i className="ri-time-line mr-1"></i>
                            {post.readTime}
                          </span>
                        </div>
                        
                        <h3 className="text-2xl font-bold text-purple-800 mb-3 group-hover:text-purple-600 transition-colors">
                          {post.title}
                        </h3>
                        
                        {post.subtitle && (
                          <p className="text-lg text-gray-700 mb-4 font-medium">
                            {post.subtitle}
                          </p>
                        )}
                        
                        <p className="text-gray-600 mb-6 line-clamp-3">
                          {post.content.split('\n')[0]}
                        </p>
                        
                        <div className="flex flex-wrap gap-2 mb-6">
                          {post.tags.map((tag, index) => (
                            <span
                              key={index}
                              className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-medium"
                            >
                              #{tag}
                            </span>
                          ))}
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="text-purple-600 font-medium group-hover:text-purple-800 transition-colors">
                            続きを読む →
                          </div>
                          <div className="flex items-center space-x-4 text-gray-400">
                            <button className="hover:text-purple-600 transition-colors cursor-pointer">
                              <i className="ri-heart-line"></i>
                            </button>
                            <button className="hover:text-purple-600 transition-colors cursor-pointer">
                              <i className="ri-bookmark-line"></i>
                            </button>
                            <button className="hover:text-purple-600 transition-colors cursor-pointer">
                              <i className="ri-share-line"></i>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <div className={`w-24 h-24 bg-gradient-to-br ${config.theme.gradients.card} rounded-full flex items-center justify-center mx-auto mb-6`}>
                  <i className="ri-lightbulb-line text-3xl text-white"></i>
                </div>
                <h3 className="text-2xl font-bold text-purple-800 mb-4">
                  記事がまだありません
                </h3>
                <p className="text-gray-600 mb-6">
                  自己啓発に関する記事を準備中です。<br />
                  しばらくお待ちください。
                </p>
              </div>
            )}
          </div>

          {/* サイドバー */}
          <div className="space-y-8">
            {/* カテゴリについて */}
            <div className="bg-white rounded-2xl shadow-lg border border-purple-100 p-6">
              <div className="flex items-center mb-4">
                <div className={`w-12 h-12 bg-gradient-to-br ${config.theme.gradients.card} rounded-full flex items-center justify-center mr-3`}>
                  <i className="ri-lightbulb-line text-xl text-white"></i>
                </div>
                <h3 className="text-xl font-bold text-purple-800">
                  自己啓発について
                </h3>
              </div>
              <p className="text-gray-600 text-sm leading-relaxed">
                日々の経験から得た学びや気づき、実践的な自己成長のヒントを共有しています。
                プログラマ、花屋、医療従事者を経て現在のケーキ屋エンジニアとしての多様な経験を活かし、
                自己効力感を高める方法を探求しています。
              </p>
            </div>

            {/* 人気のタグ */}
            <div className="bg-white rounded-2xl shadow-lg border border-purple-100 p-6">
              <h3 className="text-xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-price-tag-3-line mr-2"></i>
                人気のタグ
              </h3>
              <div className="flex flex-wrap gap-2">
                {config.tags.filter(tag => 
                  selfDevelopmentPosts.some(post => post.tags.includes(tag))
                ).map((tag, index) => (
                  <span
                    key={index}
                    className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-medium hover:bg-purple-200 transition-colors cursor-pointer"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            {/* 関連カテゴリ */}
            <div className="bg-white rounded-2xl shadow-lg border border-purple-100 p-6">
              <h3 className="text-xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-folder-line mr-2"></i>
                関連カテゴリ
              </h3>
              <div className="space-y-3">
                {config.categories.filter(cat => cat.slug !== 'self-development').map((category) => (
                  <div
                    key={category.slug}
                    className="flex items-center justify-between p-3 rounded-lg hover:bg-purple-50 transition-colors cursor-pointer group"
                  >
                    <div className="flex items-center">
                      <i className={`${category.icon} ${category.color} mr-3`}></i>
                      <span className="font-medium text-gray-700 group-hover:text-purple-700">
                        {category.name}
                      </span>
                    </div>
                    <span className="text-sm text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
                      {category.count}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* 著者情報 */}
            <div className="bg-white rounded-2xl shadow-lg border border-purple-100 p-6">
              <div className="text-center">
                <div className={`w-16 h-16 bg-gradient-to-br ${config.theme.gradients.card} rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <span className="text-2xl font-bold text-white">
                    {config.author.avatar}
                  </span>
                </div>
                <h3 className="text-xl font-bold text-purple-800 mb-2">
                  {config.author.name}
                </h3>
                <p className="text-sm text-gray-600 mb-4 whitespace-pre-line">
                  {config.author.bio}
                </p>
                <p className="text-xs text-gray-500 leading-relaxed">
                  {config.author.description}
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
