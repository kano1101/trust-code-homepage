
import Header from './home/components/Header';
import Footer from './home/components/Footer';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-white flex flex-col">
      <Header />
      
      <main className="flex-grow flex items-center justify-center px-4">
        <div className="text-center">
          <div className="w-32 h-32 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-8">
            <i className="ri-error-warning-line text-5xl text-white"></i>
          </div>
          
          <h1 className="text-6xl font-bold text-purple-800 mb-4">404</h1>
          <h2 className="text-2xl font-semibold text-purple-700 mb-6">
            ページが見つかりません
          </h2>
          <p className="text-gray-600 mb-8 max-w-md mx-auto">
            お探しのページは存在しないか、移動された可能性があります。
            URLをご確認いただくか、ホームページからお探しください。
          </p>
          
          <div className="space-y-4">
            <a 
              href="/" 
              className="inline-flex items-center px-8 py-3 bg-gradient-to-r from-purple-600 to-purple-700 text-white font-semibold rounded-lg hover:from-purple-700 hover:to-purple-800 transition-all cursor-pointer whitespace-nowrap"
            >
              <i className="ri-home-line mr-2"></i>
              ホームに戻る
            </a>
            
            <div className="flex justify-center space-x-4 text-sm">
              <a href="/categories" className="text-purple-600 hover:text-purple-800 transition-colors cursor-pointer">
                カテゴリ一覧
              </a>
              <span className="text-gray-400">|</span>
              <a href="/about" className="text-purple-600 hover:text-purple-800 transition-colors cursor-pointer">
                About
              </a>
              <span className="text-gray-400">|</span>
              <a href="/contact" className="text-purple-600 hover:text-purple-800 transition-colors cursor-pointer">
                お問い合わせ
              </a>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}