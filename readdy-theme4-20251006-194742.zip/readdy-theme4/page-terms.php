<?php
/**
 * Template for custom page
 */

get_header();
?>

<div id="root"></div>

<?php
get_footer();
