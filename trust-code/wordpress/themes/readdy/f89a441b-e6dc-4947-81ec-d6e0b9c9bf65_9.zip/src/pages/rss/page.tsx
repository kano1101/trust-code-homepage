
import { useEffect, useState } from 'react';
import Header from '../home/components/Header';
import Footer from '../home/components/Footer';
import { posts } from '../../data/posts';

export default function RSS() {
  const [rssContent, setRssContent] = useState('');

  useEffect(() => {
    const generateRSS = () => {
      const siteUrl = window.location.origin;
      const currentDate = new Date().toISOString();
      
      const rssItems = posts.map(post => `
    <item>
      <title><![CDATA[${post.title}]]></title>
      <description><![CDATA[${post.excerpt}]]></description>
      <link>${siteUrl}/posts/${post.slug}</link>
      <guid>${siteUrl}/posts/${post.slug}</guid>
      <pubDate>${new Date(post.date).toUTCString()}</pubDate>
      <category><![CDATA[${post.category}]]></category>
      <author><![CDATA[${post.author}]]></author>
    </item>`).join('');

      const rss = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title><![CDATA[TrustCode]]></title>
    <description><![CDATA[ケーキ屋の社内エンジニアAqunが、自己啓発、アクアリウム、ガジェット、プログラミング、AI・ITについて綴るブログサイト]]></description>
    <link>${siteUrl}</link>
    <atom:link href="${siteUrl}/rss" rel="self" type="application/rss+xml"/>
    <language>ja</language>
    <lastBuildDate>${currentDate}</lastBuildDate>
    <generator>TrustCode RSS Generator</generator>
    <webMaster>contact@trust-code.net (Aqun)</webMaster>
    <managingEditor>contact@trust-code.net (Aqun)</managingEditor>
    <copyright>© 2025 TrustCode by Aqun. All rights reserved.</copyright>
    <category><![CDATA[自己啓発]]></category>
    <category><![CDATA[アクアリウム]]></category>
    <category><![CDATA[ガジェット]]></category>
    <category><![CDATA[プログラミング]]></category>
    <category><![CDATA[AI・IT]]></category>
    <image>
      <url>${siteUrl}/favicon.ico</url>
      <title><![CDATA[TrustCode]]></title>
      <link>${siteUrl}</link>
    </image>${rssItems}
  </channel>
</rss>`;

      setRssContent(rss);
    };

    generateRSS();
  }, []);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(window.location.origin + '/rss');
    alert('RSS URLをクリップボードにコピーしました！');
  };

  const downloadRSS = () => {
    const blob = new Blob([rssContent], { type: 'application/rss+xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'trustcode-rss.xml';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-white flex flex-col">
      <Header />
      
      <main className="max-w-6xl mx-auto px-4 py-12 flex-grow">
        <div className="text-center mb-12">
          <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="ri-rss-line text-white text-2xl"></i>
          </div>
          <h1 className="text-4xl font-bold text-purple-800 mb-4">RSS フィード</h1>
          <p className="text-xl text-gray-600">最新記事を購読して、更新情報をいち早くキャッチ</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <div className="flex items-center mb-6">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mr-4">
                <i className="ri-information-line text-orange-600 text-xl"></i>
              </div>
              <h2 className="text-2xl font-bold text-purple-800">RSSフィードについて</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <p>
                RSSフィードを使用すると、TrustCodeの最新記事を自動的に受信できます。
                お気に入りのRSSリーダーに登録して、更新情報をお見逃しなく！
              </p>
              
              <div className="bg-orange-50 rounded-lg p-4">
                <h3 className="font-semibold text-orange-800 mb-2">RSS URL</h3>
                <div className="flex items-center space-x-2">
                  <code className="flex-1 bg-white px-3 py-2 rounded border text-sm">
                    {window.location.origin}/rss
                  </code>
                  <button 
                    onClick={copyToClipboard}
                    className="px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
                  >
                    コピー
                  </button>
                </div>
              </div>
              
              <p>
                上記のURLをRSSリーダーに登録するか、右側のボタンからRSSフィードをダウンロードしてください。
              </p>
            </div>
          </div>
          
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <div className="flex items-center mb-6">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mr-4">
                <i className="ri-download-line text-purple-600 text-xl"></i>
              </div>
              <h2 className="text-2xl font-bold text-purple-800">フィードのダウンロード</h2>
            </div>
            
            <div className="space-y-4 text-gray-700 mb-8">
              <p>
                ご利用のRSSリーダーがURL登録に対応していない場合、
                以下のボタンからRSSフィードをダウンロードし、
                リーダーにインポートしてください。
              </p>
            </div>
            
            <div className="text-center">
              <button 
                onClick={downloadRSS}
                className="px-6 py-3 bg-gradient-to-r from-purple-600 to-purple-700 text-white font-semibold rounded-lg hover:from-purple-700 hover:to-purple-800 transition-all shadow-md"
              >
                RSSフィードをダウンロード
              </button>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8">
          <h2 className="text-2xl font-bold text-purple-800 mb-6">最近の記事</h2>
          
          <div className="space-y-6">
            {posts.slice(0, 5).map((post, index) => (
              <div key={index} className="border-b border-gray-200 pb-6 last:border-0 last:pb-0">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">{post.title}</h3>
                <p className="text-gray-600 mb-3">{post.excerpt}</p>
                <div className="flex items-center text-sm text-gray-500">
                  <span className="mr-4">{new Date(post.date).toLocaleDateString('ja-JP')}</span>
                  <span className="bg-purple-100 text-purple-800 px-2 py-1 rounded">{post.category}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
