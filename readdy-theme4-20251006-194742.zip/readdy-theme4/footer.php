<?php wp_footer(); ?>

<!-- Readdy Agent Widget -->
<script
  src="https://readdy.ai/api/public/assistant/widget?projectId=f89a441b-e6dc-4947-81ec-d6e0b9c9bf65"
  mode="hybrid"
  voice-show-transcript="true"
  theme="light"
  size="compact"
  accent-color="#14B8A6"
  button-base-color="#7C3AED"
  button-accent-color="#FFFFFF"
  defer
></script>
</body>
</html>