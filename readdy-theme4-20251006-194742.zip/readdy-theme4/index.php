<?php
/**
 * Main template file
 * Loads the React SPA
 */

get_header();
?>

<div id="root"></div>

<?php
get_footer();
