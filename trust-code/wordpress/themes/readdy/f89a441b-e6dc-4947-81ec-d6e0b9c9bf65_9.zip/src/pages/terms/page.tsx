
import Header from '../home/components/Header';
import Footer from '../home/components/Footer';

export default function Terms() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-white flex flex-col">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 py-12 flex-grow">
        <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
          <div className="text-center mb-12">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-purple-700 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ri-file-text-line text-white text-2xl"></i>
            </div>
            <h1 className="text-4xl font-bold text-purple-800 mb-4">利用規約</h1>
            <p className="text-gray-600">最終更新日：2025年1月1日</p>
          </div>

          <div className="prose prose-lg max-w-none">
            <div className="bg-purple-50 rounded-xl p-6 mb-8">
              <p className="text-gray-700 leading-relaxed mb-0">
                この利用規約（以下「本規約」）は、TrustCode（以下「当サイト」）が提供するサービスの利用条件を定めるものです。
                当サイトをご利用になる場合には、本規約にご同意いただいたものとみなします。
              </p>
            </div>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-article-line mr-3"></i>
                第1条（適用）
              </h2>
              <div className="bg-white border border-purple-200 rounded-lg p-6">
                <ol className="list-decimal list-inside text-gray-700 space-y-3">
                  <li>本規約は、ユーザーと当サイトとの間の当サイトの利用に関わる一切の関係に適用されるものとします。</li>
                  <li>当サイトは本サービスに関し、本規約のほか、ご利用にあたってのルール等、各種の定め（以下「個別規定」）をすることがあります。これら個別規定はその名称のいかんに関わらず、本規約の一部を構成するものとします。</li>
                  <li>本規約の規定が前項の個別規定の規定と矛盾する場合には、個別規定において特段の定めなき限り、個別規定の規定が優先されるものとします。</li>
                </ol>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-user-line mr-3"></i>
                第2条（利用登録）
              </h2>
              <div className="bg-white border border-purple-200 rounded-lg p-6">
                <ol className="list-decimal list-inside text-gray-700 space-y-3">
                  <li>当サイトにおいては、登録希望者が本規約に同意の上、当サイトの定める方法によって利用登録を申請し、当サイトがこれを承認することによって、利用登録が完了するものとします。</li>
                  <li>当サイトは、利用登録の申請者に以下の事由があると判断した場合、利用登録の申請を承認しないことがあり、その理由については一切の開示義務を負わないものとします。
                    <ul className="list-disc list-inside ml-6 mt-2 space-y-1">
                      <li>利用登録の申請に際して虚偽の事項を届け出た場合</li>
                      <li>本規約に違反したことがある者からの申請である場合</li>
                      <li>その他、当サイトが利用登録を相当でないと判断した場合</li>
                    </ul>
                  </li>
                </ol>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-forbid-line mr-3"></i>
                第3条（禁止事項）
              </h2>
              <div className="bg-white border border-purple-200 rounded-lg p-6">
                <p className="text-gray-700 mb-4">ユーザーは、当サイトの利用にあたり、以下の行為をしてはなりません。</p>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>法令または公序良俗に違反する行為</li>
                  <li>犯罪行為に関連する行為</li>
                  <li>当サイトのサーバーまたはネットワークの機能を破壊したり、妨害したりする行為</li>
                  <li>当サイトのサービスの運営を妨害するおそれのある行為</li>
                  <li>他のユーザーに関する個人情報等を収集または蓄積する行為</li>
                  <li>他のユーザーに成りすます行為</li>
                  <li>当サイトのサービスに関連して、反社会的勢力に対して直接または間接に利益を供与する行為</li>
                  <li>その他、当サイトが不適切と判断する行為</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-copyright-line mr-3"></i>
                第4条（著作権）
              </h2>
              <div className="bg-white border border-purple-200 rounded-lg p-6">
                <ol className="list-decimal list-inside text-gray-700 space-y-3">
                  <li>ユーザーは、自ら著作権等の必要な知的財産権を有するか、または必要な権利者の許諾を得た文章、画像や映像等の情報に関してのみ、当サイトに投稿することができるものとします。</li>
                  <li>ユーザーが当サイトに投稿した文章、画像、映像等の著作権については、当該ユーザーその他既存の権利者に留保されるものとします。ただし、当サイトは、当サイトを利用して投稿された文章、画像、映像等について、当サイトの改良、品質の向上、または不備の是正等ならびにサービス向上を目的として利用できるものとし、ユーザーは、この利用に関して、著作者人格権を行使しないものとします。</li>
                  <li>前項本文の定めるものを除き、当サイトおよび当サイトに掲載されている情報についての著作権やその他の知的財産権は全て当サイトまたは当サイトにその利用を許諾した権利者に属し、ユーザーは無断で複製、譲渡、貸与、翻訳、改変、転載、公衆送信（送信可能化を含みます。）、伝送、配布、出版、営業使用等をしてはならないものとします。</li>
                </ol>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-shield-cross-line mr-3"></i>
                第5条（免責事項）
              </h2>
              <div className="bg-white border border-purple-200 rounded-lg p-6">
                <ol className="list-decimal list-inside text-gray-700 space-y-3">
                  <li>当サイトは、当サイトに事実上または法律上の瑕疵（安全性、信頼性、正確性、完全性、有効性、特定の目的への適合性、セキュリティなどに関する欠陥、エラーやバグ、権利侵害などを含みます。）がないことを明示的にも黙示的にも保証しておりません。</li>
                  <li>当サイトは、当サイトに起因してユーザーに生じたあらゆる損害について一切の責任を負いません。ただし、当サイトとユーザーとの間の契約（本規約を含みます。）が消費者契約法に定める消費者契約となる場合、この免責規定は適用されません。</li>
                  <li>前項ただし書に定める場合であっても、当サイトは、当サイトの過失（重過失を除きます。）による債務不履行または不法行為によりユーザーに生じた損害のうち特別な事情から生じた損害（当サイトまたはユーザーが損害発生につき予見し、または予見し得た場合を含みます。）について一切の責任を負いません。</li>
                </ol>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-service-line mr-3"></i>
                第6条（サービス内容の変更等）
              </h2>
              <div className="bg-white border border-purple-200 rounded-lg p-6">
                <p className="text-gray-700">
                  当サイトは、ユーザーに通知することなく、当サイトの内容を変更しまたは当サイトの提供を中断または中止することができるものとします。これによってユーザーに生じた損害について一切の責任を負いません。
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-refresh-line mr-3"></i>
                第7条（利用規約の変更）
              </h2>
              <div className="bg-white border border-purple-200 rounded-lg p-6">
                <ol className="list-decimal list-inside text-gray-700 space-y-3">
                  <li>当サイトは、必要と判断した場合には、ユーザーに通知することなくいつでも本規約を変更することができるものとします。</li>
                  <li>本規約の変更後、当サイトの利用を開始した場合には、当該ユーザーは変更後の規約に同意したものとみなします。</li>
                </ol>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-scales-line mr-3"></i>
                第8条（準拠法・裁判管轄）
              </h2>
              <div className="bg-white border border-purple-200 rounded-lg p-6">
                <ol className="list-decimal list-inside text-gray-700 space-y-3">
                  <li>本規約の解釈にあたっては、日本法を準拠法とします。</li>
                  <li>当サイトに関して紛争が生じた場合には、当サイトの本店所在地を管轄する裁判所を専属的合意管轄とします。</li>
                </ol>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-mail-line mr-3"></i>
                お問い合わせ
              </h2>
              <div className="bg-gradient-to-r from-purple-100 to-yellow-100 rounded-lg p-6">
                <p className="text-gray-700 mb-4">
                  本利用規約に関するご質問やご不明な点がございましたら、
                  以下の方法でお問い合わせください。
                </p>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center">
                    <i className="ri-mail-line text-purple-600 mr-2"></i>
                    <span className="text-gray-700">contact@trust-code.net</span>
                  </div>
                  <a 
                    href="/contact" 
                    className="inline-flex items-center px-4 py-2 bg-purple-600 text-white font-semibold rounded-lg hover:bg-purple-700 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    お問い合わせフォーム
                  </a>
                </div>
              </div>
            </section>

            <div className="text-center pt-8 border-t border-gray-200">
              <p className="text-gray-600">
                運営者：Aqun<br />
                サイト名：TrustCode<br />
                最終更新日：2025年1月1日
              </p>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
