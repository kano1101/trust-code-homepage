
import Header from '../home/components/Header';
import Footer from '../home/components/Footer';

export default function Privacy() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-white flex flex-col">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 py-12 flex-grow">
        <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
          <div className="text-center mb-12">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-purple-700 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ri-shield-check-line text-white text-2xl"></i>
            </div>
            <h1 className="text-4xl font-bold text-purple-800 mb-4">プライバシーポリシー</h1>
            <p className="text-gray-600">最終更新日：2025年1月1日</p>
          </div>

          <div className="prose prose-lg max-w-none">
            <div className="bg-purple-50 rounded-xl p-6 mb-8">
              <p className="text-gray-700 leading-relaxed mb-0">
                TrustCode（以下「当サイト」）は、ユーザーの個人情報の保護を重要視し、個人情報保護法を遵守して適切に取り扱います。
                本プライバシーポリシーでは、当サイトにおける個人情報の取り扱いについて説明いたします。
              </p>
            </div>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-information-line mr-3"></i>
                収集する情報
              </h2>
              <div className="bg-white border border-purple-200 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-purple-700 mb-3">1. 個人情報</h3>
                <ul className="list-disc list-inside text-gray-700 space-y-2 mb-6">
                  <li>お問い合わせフォームで入力されたお名前、メールアドレス</li>
                  <li>コメント投稿時に入力された情報</li>
                  <li>ニュースレター購読時のメールアドレス</li>
                </ul>

                <h3 className="text-lg font-semibold text-purple-700 mb-3">2. 自動収集される情報</h3>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>IPアドレス、ブラウザの種類、OS情報</li>
                  <li>アクセス日時、参照元URL</li>
                  <li>Cookie情報</li>
                  <li>Google Analyticsによるアクセス解析データ</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-target-line mr-3"></i>
                情報の利用目的
              </h2>
              <div className="bg-white border border-purple-200 rounded-lg p-6">
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>お問い合わせへの回答および連絡</li>
                  <li>サイトの運営、改善、統計分析</li>
                  <li>ニュースレターの配信</li>
                  <li>不正利用の防止およびセキュリティ向上</li>
                  <li>法的義務の履行</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-cookie-line mr-3"></i>
                Cookieについて
              </h2>
              <div className="bg-white border border-purple-200 rounded-lg p-6">
                <p className="text-gray-700 mb-4">
                  当サイトでは、ユーザー体験の向上とサイト分析のためにCookieを使用しています。
                </p>
                <h3 className="text-lg font-semibold text-purple-700 mb-3">使用するCookie</h3>
                <ul className="list-disc list-inside text-gray-700 space-y-2 mb-4">
                  <li><strong>必須Cookie：</strong>サイトの基本機能に必要</li>
                  <li><strong>分析Cookie：</strong>Google Analyticsによるアクセス解析</li>
                  <li><strong>機能Cookie：</strong>ユーザー設定の保存</li>
                </ul>
                <p className="text-gray-700">
                  ブラウザの設定でCookieを無効にすることができますが、一部機能が制限される場合があります。
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-share-line mr-3"></i>
                第三者への提供
              </h2>
              <div className="bg-white border border-purple-200 rounded-lg p-6">
                <p className="text-gray-700 mb-4">
                  当サイトは、以下の場合を除き、個人情報を第三者に提供することはありません。
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>ユーザーの同意がある場合</li>
                  <li>法令に基づく場合</li>
                  <li>人の生命、身体または財産の保護のために必要がある場合</li>
                  <li>公衆衛生の向上または児童の健全な育成の推進のために特に必要がある場合</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-external-link-line mr-3"></i>
                外部サービス
              </h2>
              <div className="bg-white border border-purple-200 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-purple-700 mb-3">Google Analytics</h3>
                <p className="text-gray-700 mb-4">
                  当サイトでは、Googleが提供するアクセス解析ツール「Google Analytics」を使用しています。
                  Google Analyticsは、トラフィックデータの収集のためにCookieを使用しています。
                </p>
                <p className="text-gray-700 mb-6">
                  詳細は<a href="https://policies.google.com/privacy" className="text-purple-600 hover:text-purple-800 underline" target="_blank" rel="noopener noreferrer">Googleプライバシーポリシー</a>をご確認ください。
                </p>

                <h3 className="text-lg font-semibold text-purple-700 mb-3">その他の外部サービス</h3>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>SNS連携機能（Twitter、GitHub、LinkedIn）</li>
                  <li>コンテンツ配信ネットワーク（CDN）</li>
                  <li>フォント配信サービス（Google Fonts）</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-shield-line mr-3"></i>
                セキュリティ
              </h2>
              <div className="bg-white border border-purple-200 rounded-lg p-6">
                <p className="text-gray-700">
                  当サイトは、個人情報の漏洩、滅失、毀損を防止するため、適切なセキュリティ対策を実施しています。
                  ただし、インターネット上での情報伝達は完全に安全ではないことをご理解ください。
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-user-settings-line mr-3"></i>
                ユーザーの権利
              </h2>
              <div className="bg-white border border-purple-200 rounded-lg p-6">
                <p className="text-gray-700 mb-4">
                  ユーザーは、自身の個人情報について以下の権利を有します。
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>個人情報の開示請求</li>
                  <li>個人情報の訂正・削除請求</li>
                  <li>個人情報の利用停止請求</li>
                  <li>ニュースレターの配信停止</li>
                </ul>
                <p className="text-gray-700 mt-4">
                  これらの請求については、<a href="/contact" className="text-purple-600 hover:text-purple-800 underline">お問い合わせフォーム</a>よりご連絡ください。
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-refresh-line mr-3"></i>
                プライバシーポリシーの変更
              </h2>
              <div className="bg-white border border-purple-200 rounded-lg p-6">
                <p className="text-gray-700">
                  当サイトは、必要に応じて本プライバシーポリシーを変更することがあります。
                  変更した場合は、当サイト上で通知いたします。
                  変更後のプライバシーポリシーは、当サイトに掲載した時点から効力を生じるものとします。
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-mail-line mr-3"></i>
                お問い合わせ
              </h2>
              <div className="bg-gradient-to-r from-purple-100 to-yellow-100 rounded-lg p-6">
                <p className="text-gray-700 mb-4">
                  本プライバシーポリシーに関するご質問やご不明な点がございましたら、
                  以下の方法でお問い合わせください。
                </p>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center">
                    <i className="ri-mail-line text-purple-600 mr-2"></i>
                    <span className="text-gray-700">contact@trust-code.net</span>
                  </div>
                  <a 
                    href="/contact" 
                    className="inline-flex items-center px-4 py-2 bg-purple-600 text-white font-semibold rounded-lg hover:bg-purple-700 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    お問い合わせフォーム
                  </a>
                </div>
              </div>
            </section>

            <div className="text-center pt-8 border-t border-gray-200">
              <p className="text-gray-600">
                運営者：Aqun<br />
                サイト名：TrustCode<br />
                最終更新日：2025年1月1日
              </p>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
