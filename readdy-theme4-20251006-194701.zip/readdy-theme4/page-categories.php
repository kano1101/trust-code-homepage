<?php
/**
 * Template Name: Categories Page
 * Template for displaying categories
 */

get_header();
?>

<div id="root"></div>

<?php
get_footer();